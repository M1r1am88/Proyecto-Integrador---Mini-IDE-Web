async function analyzeCode() {
    const code = document.getElementById('editor').value;
    const response = await fetch('/analyze', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({code: code})
    });
    const result = await response.json();
    document.getElementById('lexResult').textContent = JSON.stringify(result.lex, null, 2);
    const parseErrors = result.parse.errors.map(e => `Error: ${e.error} en posición ${e.position}`);
    document.getElementById('parseResult').textContent = parseErrors.join('\n') || "Sin errores";
}

async function simulateTuring() {
    const tape = document.getElementById('turingInput').value;
    const response = await fetch('/turing', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({tape: tape})
    });
    const result = await response.json();
    document.getElementById('turingResult').textContent = result.result;
}
