import lexer

def parse(code):
    tokens = [tok for tok in lexer.analyze(code) if tok['type'] != 'WHITESPACE']
    errors = []
    
    # Verificar paréntesis balanceados
    paren_count = 0
    for tok in tokens:
        if tok['type'] == 'LPAREN':
            paren_count += 1
        elif tok['type'] == 'RPAREN':
            paren_count -= 1
            if paren_count < 0:
                errors.append({
                    'error': 'Paréntesis de cierre sin paréntesis de apertura',
                    'position': tok['position']
                })
    
    if paren_count > 0:
        errors.append({
            'error': 'Paréntesis sin cerrar al final del código',
            'position': len(code)
        })

    # Verificar sintaxis de asignación y expresiones
    i = 0
    while i < len(tokens):
        token = tokens[i]
        
        # Verificar que las variables sean válidas
        if token['type'] == 'IDENT':
            # Si es una variable seguida de un igual, debe ser una asignación
            if i + 1 < len(tokens) and tokens[i + 1]['type'] == 'EQUALS':
                if i + 2 >= len(tokens):
                    errors.append({
                        'error': 'Falta valor después del signo igual',
                        'position': tokens[i + 1]['position']
                    })
            # Si es una variable no seguida de un igual, debe ser parte de una expresión
            elif i + 1 < len(tokens) and tokens[i + 1]['type'] not in ['PLUS', 'MINUS', 'MULTIPLY', 'DIVIDE', 'SEMICOLON']:
                errors.append({
                    'error': 'Se esperaba un operador después de la variable',
                    'position': token['position']
                })
        
        # Verificar que los números sean seguidos por operadores o punto y coma
        elif token['type'] == 'NUMBER':
            if i + 1 < len(tokens) and tokens[i + 1]['type'] not in ['PLUS', 'MINUS', 'MULTIPLY', 'DIVIDE', 'SEMICOLON']:
                errors.append({
                    'error': 'Se esperaba un operador o punto y coma después del número',
                    'position': token['position']
                })
        
        # Verificar que los operadores tengan operandos válidos
        elif token['type'] in ['PLUS', 'MINUS', 'MULTIPLY', 'DIVIDE']:
            if i == 0:
                errors.append({
                    'error': 'Operador al inicio de la expresión',
                    'position': token['position']
                })
            elif i == len(tokens) - 1:
                errors.append({
                    'error': 'Operador al final de la expresión',
                    'position': token['position']
                })
            elif tokens[i - 1]['type'] not in ['NUMBER', 'IDENT', 'RPAREN'] or \
                 tokens[i + 1]['type'] not in ['NUMBER', 'IDENT', 'LPAREN']:
                errors.append({
                    'error': 'Operador sin operandos válidos',
                    'position': token['position']
                })
        
        # Verificar punto y coma al final de cada instrucción
        elif token['type'] == 'SEMICOLON':
            if i == 0:
                errors.append({
                    'error': 'Punto y coma al inicio de la instrucción',
                    'position': token['position']
                })
            elif tokens[i - 1]['type'] not in ['NUMBER', 'IDENT', 'RPAREN']:
                errors.append({
                    'error': 'Punto y coma en posición incorrecta',
                    'position': token['position']
                })
        
        i += 1
    
    # Verificar que el código termine con punto y coma
    if tokens and tokens[-1]['type'] != 'SEMICOLON':
        errors.append({
            'error': 'Falta punto y coma al final de la instrucción',
            'position': len(code)
        })

    return {
        'errors': errors,
        'tokens': [{'type': t['type'], 'value': t['value'], 'position': t['position']} for t in tokens]
    } 