function showStatus(elementId, success, message) {
    const statusElement = document.getElementById(elementId);
    statusElement.className = 'status ' + (success ? 'success' : 'error');
    statusElement.textContent = message;
}

function analyzeCode() {
    const code = document.getElementById('editor').value;
    
    fetch('/analyze', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code: code })
    })
    .then(response => response.json())
    .then(data => {
        // Mostrar resultados léxicos
        const lexResult = document.getElementById('lexResult');
        if (data.lex.some(token => token.type === 'ERROR')) {
            showStatus('lexStatus', false, '❌ Error léxico encontrado');
        } else {
            showStatus('lexStatus', true, '✅ Análisis léxico exitoso');
        }
        lexResult.textContent = JSON.stringify(data.lex, null, 2);

        // Mostrar resultados sintácticos
        const parseResult = document.getElementById('parseResult');
        if (data.parse.errors.length > 0) {
            showStatus('parseStatus', false, '❌ Errores sintácticos encontrados');
        } else {
            showStatus('parseStatus', true, '✅ Análisis sintáctico exitoso');
        }
        parseResult.textContent = JSON.stringify(data.parse.errors, null, 2);
    })
    .catch(error => {
        console.error('Error:', error);
        showStatus('lexStatus', false, '❌ Error al analizar');
        showStatus('parseStatus', false, '❌ Error al analizar');
    });
}

function renderTuringTape(tape, headPosition) {
    const tapeElement = document.getElementById('turingTape');
    tapeElement.innerHTML = '';
    
    tape.split('').forEach((symbol, index) => {
        const cell = document.createElement('span');
        cell.className = 'tape-cell' + (index === headPosition ? ' head' : '');
        cell.textContent = symbol;
        tapeElement.appendChild(cell);
    });
}

function simulateTuring() {
    const tape = document.getElementById('turingInput').value;
    
    if (!/^[01]+$/.test(tape)) {
        showStatus('turingStatus', false, '❌ Error: La cinta solo puede contener 0s y 1s');
        return;
    }
    
    fetch('/turing', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tape: tape })
    })
    .then(response => response.json())
    .then(data => {
        const stepsDiv = document.getElementById('turingSteps');
        stepsDiv.innerHTML = '';
        
        if (data.accepted) {
            showStatus('turingStatus', true, '✅ Simulación completada exitosamente');
        } else {
            showStatus('turingStatus', false, '❌ La máquina se detuvo sin aceptar');
        }

        // Mostrar los pasos de la simulación
        data.history.forEach((step, index) => {
            const stepDiv = document.createElement('div');
            stepDiv.className = 'step';
            stepDiv.innerHTML = `
                <strong>Paso ${step.step}:</strong>
                Estado: ${step.state}
            `;
            stepsDiv.appendChild(stepDiv);
            renderTuringTape(step.tape, step.head);
        });
    })
    .catch(error => {
        console.error('Error:', error);
        showStatus('turingStatus', false, '❌ Error en la simulación');
    });
} 