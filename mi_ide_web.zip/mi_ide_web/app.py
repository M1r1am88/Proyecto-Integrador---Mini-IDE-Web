from flask import Flask, render_template, request, jsonify
import lexer
import parser as parser_module
import turing_machine

app = Flask(__name__)

STUDENT_INFO = {
    'name': 'Miriam Martinez',
    'subject': 'Lenguajes y Autómatas 1 ',
    'professor': 'Ing. Kevin David Molina'
}

@app.route('/')
def index():
    return render_template('index.html', student_info=STUDENT_INFO)

@app.route('/analyze', methods=['POST'])
def analyze():
    code = request.json['code']
    lex_result = lexer.analyze(code)
    parse_result = parser_module.parse(code)
    return jsonify({'lex': lex_result, 'parse': parse_result})

@app.route('/turing', methods=['POST'])
def turing():
    tape = request.json['tape']
    try:
        # Crear una instancia de la máquina de Turing
        result = turing_machine.simulate(tape)
        return jsonify(result)  # Ya no necesitamos envolver en {'result': result}
    except Exception as e:
        return jsonify({
            'error': str(e),
            'accepted': False,
            'steps': 0,
            'final_tape': tape,
            'history': [{
                'step': 0,
                'tape': tape,
                'state': 'error',
                'head': 0
            }]
        }), 400

if __name__ == '__main__':
    print(f"Estudiante: {STUDENT_INFO['name']}")
    print(f"Materia: {STUDENT_INFO['subject']}")
    print(f"Profesor: {STUDENT_INFO['professor']}")
    app.run(debug=True)
