class TuringMachine:
    def __init__(self):
        # Definir los estados y transiciones de la máquina
        # La máquina acepta cadenas de 1s y las convierte en Xs
        self.transitions = {
            'q0': {  # Estado inicial
                '0': ('q0', '0', 'R'),  # Si lee 0, mantiene 0 y mueve derecha
                '1': ('q1', 'X', 'R'),  # Si lee 1, cambia a X y mueve derecha
                '_': ('qf', '_', 'S')   # Si lee blanco, termina
            },
            'q1': {  # Estado de conteo
                '0': ('q1', '0', 'R'),  # Si lee 0, mantiene 0 y mueve derecha
                '1': ('q1', '1', 'R'),  # Si lee 1, mantiene 1 y mueve derecha
                '_': ('q2', '_', 'L')   # Si lee blanco, retrocede
            },
            'q2': {  # Estado de retorno
                '0': ('q2', '0', 'L'),  # Si lee 0, mantiene 0 y mueve izquierda
                '1': ('q2', '1', 'L'),  # Si lee 1, mantiene 1 y mueve izquierda
                'X': ('q0', 'X', 'R'),  # Si lee X, vuelve al inicio
                '_': ('qf', '_', 'S')   # Si lee blanco, termina
            }
        }

def simulate(input_tape):
    # Validar la entrada
    if not all(c in '01' for c in input_tape):
        raise ValueError("La cinta solo puede contener 0s y 1s")
    
    # Crear instancia de la máquina
    tm = TuringMachine()
    
    # Inicializar la cinta con el input y espacio extra
    tape = list(input_tape) + ['_'] * 10
    
    # Estado inicial y posición del cabezal
    state = 'q0'
    head = 0
    steps = 0
    max_steps = 100
    
    # Historial para mostrar la ejecución
    history = [{
        'step': steps,
        'tape': ''.join(tape),
        'state': state,
        'head': head
    }]
    
    # Ejecutar la máquina
    while state != 'qf' and steps < max_steps:
        # Leer símbolo actual
        current_symbol = tape[head]
        
        # Si no hay transición definida, terminar
        if state not in tm.transitions or current_symbol not in tm.transitions[state]:
            break
        
        # Obtener la siguiente transición
        next_state, write_symbol, move = tm.transitions[state][current_symbol]
        
        # Ejecutar la transición
        tape[head] = write_symbol
        state = next_state
        
        # Mover el cabezal
        if move == 'R':
            head += 1
            if head >= len(tape):
                tape.append('_')
        elif move == 'L':
            head = max(0, head - 1)
        
        steps += 1
        
        # Guardar el estado actual en el historial
        history.append({
            'step': steps,
            'tape': ''.join(tape),
            'state': state,
            'head': head
        })
    
    # Determinar si la entrada fue aceptada
    accepted = state == 'qf'
    
    return {
        'accepted': accepted,
        'steps': steps,
        'final_tape': ''.join(tape).rstrip('_'),
        'history': history
    }
