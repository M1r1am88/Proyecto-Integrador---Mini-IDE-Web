import re

TOKENS = [
    ('NUMBER', r'\d+(\.\d+)?'),  # Números enteros y decimales
    ('PLUS', r'\+'),
    ('MINUS', r'-'),
    ('MULTIPLY', r'\*'),
    ('DIVIDE', r'/'),
    ('EQUALS', r'='),
    ('SEMICOLON', r';'),
    ('LPAREN', r'\('),
    ('RPAREN', r'\)'),
    ('IDENT', r'[a-zA-Z_]\w*'),
    ('WHITESPACE', r'\s+'),
    ('UNKNOWN', r'.'),
]

def analyze(code):
    tokens = []
    pos = 0
    while pos < len(code):
        match = None
        for tok_type, tok_regex in TOKENS:
            regex = re.compile(tok_regex)
            match = regex.match(code, pos)
            if match:
                text = match.group(0)
                if tok_type != 'WHITESPACE':
                    tokens.append({
                        'type': tok_type,
                        'value': text,
                        'position': pos
                    })
                pos = match.end()
                break
        if not match:
            tokens.append({
                'type': 'ERROR',
                'value': code[pos],
                'position': pos
            })
            pos += 1
    return tokens
